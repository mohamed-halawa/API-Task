Rails.application.routes.draw do
  # Frontend
  resources :sessions, only: [:create, :destroy]
  
  resources :users, except: [:index, :destroy] do
    member do
      get :history
    end
  end
  
  resources :products do
    member do
      get :checkout
      patch :buy
    end
  end
  
  #API
  namespace :api, defaults: { format: :json } do
    resources :sessions, only: :create
    
    resources :products, only: :index do
      member do
        patch :buy
      end
    end
  end
  
  root 'products#index'
end
