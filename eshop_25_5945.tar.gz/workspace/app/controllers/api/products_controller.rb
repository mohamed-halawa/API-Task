class Api::ProductsController < Api::BaseController
    before_action :authenticate_user!, only: :buy
    
    def index
        respond_with @products = Product.all
    end
    
    def buy
        @products = Product.find(params[:id])
        @products.buy_by(current_user)
        
        respond_with @product
    end
end